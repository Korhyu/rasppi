/* Receiver/client multicast Datagram example. */

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "defines.h"
   
struct sockaddr_in localSock;
struct ip_mreq group;
int sd;
int datalen;
char databuf[MSJ_LENGTH];

FILE * fptr;

int get_timetag(char* data, char* ttp)
{
	int sizett = sizeof(*ttp);

	strncpy(ttp, data, 16);						//Copio los prieros 16 caracteres que son el timestamp
	strcat(ttp, "\0");

	return 0;
}

int get_header(char* data, char* ttp, char* hep)
{
	int i,posp,posu;
	int cont=0;

	//Busco la posicion del primer pipe
	for(i=0; i<=40; i++)
	{
		*(ttp+i) = *(data+i);

		if(*(data+i) == '|')
		{
			posp = i;
			break;
		}
	}

	//Busco la posicion del ultimo pipe
	for(i = sizeof(hep); i < posp; i--)
	{
		if(*(data+i) == '|')
		{
			posu = i;

			break;
		}
	}

		//Copio desde el primero hasta el ultimo en el string header
	for(i = posp; i <= posu ; i++)
	{
		*(hep+i) = *(data+i);
		cont++;
	}
	*(hep+i) = '\0';

	/*
	strncpy(ttp, data, 16);						//Copio los prieros 16 caracteres que son el timestamp
	strcat(ttp, "\0");
	*/

	return cont;
}


int main(int argc, char *argv[])
{
	/* Create a datagram socket on which to receive. */
	sd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sd < 0)
	{
		perror("Opening datagram socket error");
		exit(1);
	}
	else
		printf("Opening datagram socket....OK.\n");

	/* Enable SO_REUSEADDR to allow multiple instances of this */
	/* application to receive copies of the multicast datagrams. */
	int reuse = 1;
	if(setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse)) < 0)
	{
		perror("Setting SO_REUSEADDR error");
		close(sd);
		exit(1);
	}
	else
		printf("Setting SO_REUSEADDR...OK.\n");    

	/* Bind to the proper port number with the IP address */
	/* specified as INADDR_ANY. */

	memset((char *) &localSock, 0, sizeof(localSock));

	localSock.sin_family = AF_INET;
	localSock.sin_port = htons(4321);
	localSock.sin_addr.s_addr = INADDR_ANY;

	if(bind(sd, (struct sockaddr*)&localSock, sizeof(localSock)))
	{
		perror("Binding datagram socket error");
		close(sd);
		exit(1);
	}

	else

	printf("Binding datagram socket...OK.\n");

	/* Join the multicast group 226.1.1.1 on the local 203.106.93.94 */
	/* interface. Note that this IP_ADD_MEMBERSHIP option must be */
	/* called for each local interface over which the multicast */
	/* datagrams are to be received. */

	group.imr_multiaddr.s_addr = inet_addr(IP_MCST);
	group.imr_interface.s_addr = inet_addr(IP_ADDR);
	if(setsockopt(sd, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&group, sizeof(group)) < 0)
	{
	perror("Adding multicast group error");
	close(sd);
	exit(1);
	}

	else
	printf("Adding multicast group...OK.\n");
	/* Read from the socket. */
	datalen = sizeof(databuf);

	struct timeval tv;
	long ticks;
	int cuenta=0;
	char timetag[20];				//String donde almaceno el time tag
	char header[200];				//String donde almaceno los datos del Header para luego analizarlos

	// Si existe el archivo lo piso para crear uno nuevo
	fptr = fopen("outputw.txt", "w+");
	fclose(fptr);

	while (1)
	{
		if(read(sd, databuf, datalen) < 0)
		{
			perror("Reading datagram message error");
			close(sd);
			exit(1);
		}
		else
		{
			gettimeofday(&tv, NULL);
			ticks= ((tv.tv_sec * 1000000 + tv.tv_usec));
			cuenta++;

			if(IMPRIMIR == 1)
			{
				printf("Reading N %d...OK.\n", cuenta);
				printf("Mensaje enviado por el servidor: \"%s\"\n", databuf);
				printf( "%d : %ld \n", cuenta, ticks);
			}

			//get_timetag(databuf, timetag);
			get_header(databuf, timetag, header);
			
			fptr = fopen("outputw.txt", "a+");
			fprintf(fptr, "%s,%ld,%s\n",timetag, ticks,header);
			fclose(fptr);

			if (strcmp(databuf,FIN_TRANSM) == 0)
			{
				printf("Fin de transmicion, recividos %d mensajes\n", cuenta);
				return 0;
			}
		}
	}
	return 0;
}