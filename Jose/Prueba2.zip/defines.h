#define IP_ADDR 		"192.168.1.149"			//IP del servidor y cliente
#define IP_MCST			"226.1.1.1"				//IP Mlticast
#define IMPRIMIR 		0						//0 para no hacer printf en el cliente
#define MSJ_LENGTH 		1000					//Buffer del mensaje
#define DEMORA_ENVIO 	100						//Demora en el tiempo de envio expresado en microsegundos
#define CANTIDAD_ENVIOS 100					//Cantidad de mensajes enviados
#define FIN_TRANSM		"FIN TRANSMISION"		//Cantidad de mensajes enviados
#define IMPRIMIR		0						//1 - Imprime los mensajes recividos
#define SEPAR_CAMPO 	'|'						//Caracter de separaciion de campo
